db_config={
    "dbname":"greendesign",
    "password":"sqlpassword"
}
